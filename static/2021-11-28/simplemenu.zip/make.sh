#!/bin/sh
VERSION=$1
if [ $VERSION != 3 ] ; then
	gcc `pkg-config --cflags gtk4` gtk4-simplemenu.c `pkg-config --libs gtk4` -o gtk4-simplemenu
else
	gcc `pkg-config --cflags gtk+-3.0` simplemenu.c `pkg-config --libs gtk+-3.0` -o simplemenu
fi

