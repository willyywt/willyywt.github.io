#include <gtk/gtk.h>

static void activate_quit(GSimpleAction *action, GVariant *parameter, gpointer user_data) {
  GtkApplication *app = GTK_APPLICATION(user_data);
  GtkWidget *win;
  GList *list, *next;
  for (list = gtk_application_get_windows (app); list; list = next)
    {
      win = list->data;
      next = list->next;
      gtk_window_destroy (GTK_WINDOW (win));
    }
}

static void activate(GtkApplication *app) {
  GtkWidget *window;
  GtkWidget *box;
  GtkWidget *menu_bar;
  GMenu *file_model, *menu_bar_model;
  GSimpleAction *quit_ac;
  
  window = gtk_window_new();
  gtk_window_set_default_size(GTK_WINDOW(window), 300, 200);
  gtk_window_set_title(GTK_WINDOW(window), "Simple menu");

  box = gtk_box_new(GTK_ORIENTATION_VERTICAL, 0);
  gtk_window_set_child(GTK_WINDOW(window), box);

  quit_ac = g_simple_action_new("quit", NULL);
  g_signal_connect (quit_ac, "activate", G_CALLBACK (activate_quit), app);
  g_action_map_add_action (G_ACTION_MAP (app), G_ACTION (quit_ac));

  file_model = g_menu_new();
  g_menu_append(file_model, "Quit", "app.quit");
  menu_bar_model = g_menu_new();
  g_menu_append_submenu(menu_bar_model, "File", G_MENU_MODEL(file_model));
  menu_bar = gtk_popover_menu_bar_new_from_model(G_MENU_MODEL(menu_bar_model));

  gtk_box_append(GTK_BOX(box), menu_bar);

  gtk_application_add_window(app, GTK_WINDOW(window));

  gtk_widget_show(window);
}

int main(int argc, char *argv[]) {
  GtkApplication *app = gtk_application_new (NULL, G_APPLICATION_FLAGS_NONE);
  g_signal_connect (app, "activate", G_CALLBACK (activate), NULL);
  return g_application_run (G_APPLICATION (app), argc, argv);
}

